<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\ClickerController;
use App\Http\Controllers\LevelController;
use App\Http\Controllers\PopupController;
use App\Http\Controllers\ReferralTaskController;
use App\Http\Controllers\TelegramUserController;
use App\Http\Controllers\TelegramWebhookController;
use App\Http\Controllers\UserMissionController;
use App\Http\Controllers\UserTaskController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes  (prefiks: /api)
|--------------------------------------------------------------------------
*/

// Telegram bot webhook (PHP orqali ishlaydi, pm2/Node kerak emas)
Route::post('/telegram/webhook/{secret}', [TelegramWebhookController::class, 'handle'])
    ->middleware('throttle:120,1');

// Public routes
Route::post('/auth/telegram-user', [AuthController::class, 'telegramUser'])
    ->middleware('throttle:20,1');

// popup messages
Route::get('/popups', [PopupController::class, 'index']);

// Protected routes
Route::middleware(['auth:sanctum', 'throttle:game'])->group(function () {

    Route::get('referred-users', [TelegramUserController::class, 'referredUsers']);

    Route::prefix('clicker')->group(function () {
        Route::get('/sync', [ClickerController::class, 'sync']);
        Route::post('/tap', [ClickerController::class, 'tap']);
        Route::post('/buy-booster', [ClickerController::class, 'buyBooster']);

        Route::get('/daily-tasks', [ClickerController::class, 'listDailyTasks']);
        Route::post('/claim-daily-task', [ClickerController::class, 'claimDailyTaskReward']);

        Route::get('tasks', [UserTaskController::class, 'index']);
        Route::post('tasks/{task}', [UserTaskController::class, 'store']);
        Route::post('tasks/{task}/claim', [UserTaskController::class, 'claim']);

        Route::get('referral-tasks', [ReferralTaskController::class, 'index']);
        Route::post('referral-tasks/{task}/complete', [ReferralTaskController::class, 'complete']);

        Route::get('/leaderboard', [ClickerController::class, 'listLeaderboard']);
        Route::post('/use-daily-booster', [ClickerController::class, 'useDailyBooster']);
        Route::post('/set-ton-wallet', [ClickerController::class, 'setTonWallet']);

        Route::get('missions', [UserMissionController::class, 'index']);
        Route::post('mission-levels/{missionLevel}', [UserMissionController::class, 'store']);
    });

    Route::get('levels', [LevelController::class, 'index']);
});
