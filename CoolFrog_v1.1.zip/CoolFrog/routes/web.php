<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

// Admin panel: /admin  (asosiy sahifa "/" — o'yin frontendi)
Route::prefix('admin')->group(function () {
    Route::redirect('/', '/admin/dashboard');

    Route::middleware('auth')->group(function () {
        Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
        Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
        Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

        Route::get('/dashboard', [AdminController::class, 'dashboard'])->name('dashboard');
        Route::get('/users', [AdminController::class, 'users'])->name('users');

        Route::get('/tasks', [AdminController::class, 'tasks'])->name('tasks');
        Route::get('/tasks/create', [AdminController::class, 'createTask'])->name('create_task');
        Route::post('/tasks', [AdminController::class, 'storeTask'])->name('store_task');
        Route::delete('/tasks/{task}', [AdminController::class, 'deleteTask'])->name('delete_task');

        Route::get('/daily-tasks', [AdminController::class, 'dailyTasks'])->name('daily_tasks');
        Route::get('/daily-tasks/create', [AdminController::class, 'createDailyTask'])->name('create_daily_task');
        Route::post('/daily-tasks', [AdminController::class, 'storeDailyTask'])->name('store_daily_task');
        Route::delete('/daily-tasks/{dailyTask}', [AdminController::class, 'deleteDailyTask'])->name('delete_daily_task');
    });

    require __DIR__ . '/auth.php';
});
