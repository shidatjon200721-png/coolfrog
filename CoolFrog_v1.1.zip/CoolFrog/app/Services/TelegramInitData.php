<?php

namespace App\Services;

/**
 * Telegram Mini App `initData` imzosini tekshiradi.
 * https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app
 *
 * Laravel'ga bog'liq emas — oddiy PHP (alohida test qilish mumkin).
 */
class TelegramInitData
{
    /**
     * @return array{user: array, start_param: ?string, auth_date: int}|null  Imzo noto'g'ri bo'lsa null.
     */
    public static function validate(string $initData, string $botToken, int $maxAgeSeconds = 86400, ?int $now = null): ?array
    {
        if ($initData === '' || $botToken === '') {
            return null;
        }

        parse_str($initData, $fields);

        if (!isset($fields['hash']) || !is_string($fields['hash'])) {
            return null;
        }

        $hash = $fields['hash'];
        unset($fields['hash']);

        ksort($fields);
        $pairs = [];
        foreach ($fields as $key => $value) {
            if (!is_string($value)) {
                return null;
            }
            $pairs[] = $key . '=' . $value;
        }
        $dataCheckString = implode("\n", $pairs);

        $secretKey = hash_hmac('sha256', $botToken, 'WebAppData', true);
        $calculated = hash_hmac('sha256', $dataCheckString, $secretKey);

        if (!hash_equals($calculated, strtolower($hash))) {
            return null;
        }

        $authDate = (int) ($fields['auth_date'] ?? 0);
        $now = $now ?? time();
        if ($authDate <= 0 || ($maxAgeSeconds > 0 && $now - $authDate > $maxAgeSeconds)) {
            return null;
        }

        $user = json_decode($fields['user'] ?? '', true);
        if (!is_array($user) || !isset($user['id']) || !is_numeric($user['id'])) {
            return null;
        }

        return [
            'user' => $user,
            'start_param' => isset($fields['start_param']) && is_string($fields['start_param']) ? $fields['start_param'] : null,
            'auth_date' => $authDate,
        ];
    }

    /**
     * "ref12345" -> 12345, boshqa narsa -> null
     */
    public static function referrerFromStartParam(?string $param): ?int
    {
        if ($param === null) {
            return null;
        }

        if (preg_match('/^ref(\d{1,18})$/', $param, $m)) {
            return (int) $m[1];
        }

        return null;
    }
}
