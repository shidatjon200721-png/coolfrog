<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

/**
 * Telegram Bot API bilan ishlash uchun juda yengil klient (kutubxona yoki Node/pm2 kerak emas).
 */
class TelegramApi
{
    public function __construct(private ?string $token = null)
    {
        $this->token = $token ?? (string) config('services.telegram.bot_token');
    }

    public function call(string $method, array $params = []): array
    {
        if ($this->token === '') {
            return ['ok' => false, 'description' => 'Bot token is not configured'];
        }

        try {
            $response = Http::timeout(10)
                ->asJson()
                ->post("https://api.telegram.org/bot{$this->token}/{$method}", $params);

            $json = $response->json();

            return is_array($json) ? $json : ['ok' => false, 'description' => 'Invalid response from Telegram'];
        } catch (\Throwable $e) {
            Log::warning("Telegram {$method} failed: " . $e->getMessage());

            return ['ok' => false, 'description' => $e->getMessage()];
        }
    }

    public function sendPlayButton(int $chatId, string $text, string $buttonText, string $appUrl): array
    {
        return $this->call('sendMessage', [
            'chat_id' => $chatId,
            'text' => $text,
            'reply_markup' => [
                'inline_keyboard' => [[
                    ['text' => $buttonText, 'web_app' => ['url' => $appUrl]],
                ]],
            ],
        ]);
    }

    public function setWebhook(string $url, string $secretToken): array
    {
        return $this->call('setWebhook', [
            'url' => $url,
            'secret_token' => $secretToken,
            'allowed_updates' => ['message'],
            'drop_pending_updates' => true,
            'max_connections' => 40,
        ]);
    }

    public function setMenuButton(string $appUrl, string $text = 'Play'): array
    {
        return $this->call('setChatMenuButton', [
            'menu_button' => [
                'type' => 'web_app',
                'text' => $text,
                'web_app' => ['url' => $appUrl],
            ],
        ]);
    }
}
