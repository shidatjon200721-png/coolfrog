<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Task extends Model
{
    protected $guarded = [];

    public function getImageAttribute($value)
    {
        if (!$value) {
            return null;
        }

        if (preg_match('#^https?://#i', $value)) {
            return $value;
        }

        return url('storage/' . ltrim($value, '/'));
    }

    public function telegramUsers()
    {
        return $this->belongsToMany(TelegramUser::class, 'telegram_user_tasks')
            ->withPivot('is_submitted', 'is_rewarded', 'submitted_at')
            ->withTimestamps();
    }
}
