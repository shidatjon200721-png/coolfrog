<?php

namespace App\Models;

use App\Observers\TelegramUserObserver;
use Illuminate\Database\Eloquent\Attributes\ObservedBy;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Support\Facades\DB;
use Laravel\Sanctum\HasApiTokens;

#[ObservedBy(TelegramUserObserver::class)]
class TelegramUser extends Authenticatable
{
    use HasApiTokens;

    protected $guarded = [];

    protected $hidden = [
        'remember_token',
    ];

    protected $casts = [
        'balance' => 'integer',
        'is_premium' => 'boolean',
        'booster_pack_2x' => 'boolean',
        'booster_pack_3x' => 'boolean',
        'booster_pack_7x' => 'boolean',
        'booster_pack_active_until' => 'datetime',
        'last_login_date' => 'datetime',
        'last_passive_at' => 'datetime',
        'last_tap_date' => 'datetime',
        'last_daily_booster_use' => 'datetime',
    ];

    /** Boshqa o'yinchilarga ko'rsatiladigan xavfsiz ustunlar (reyting, do'stlar ro'yxati). */
    public const PUBLIC_COLUMNS = [
        'id', 'telegram_id', 'first_name', 'last_name', 'username',
        'balance', 'production_per_hour', 'level_id', 'created_at',
    ];

    public function referrals()
    {
        return $this->hasMany(self::class, 'referred_by', 'telegram_id');
    }

    public function dailyTasks()
    {
        return $this->belongsToMany(DailyTask::class, 'telegram_user_daily_tasks')
            ->withPivot('completed', 'created_at')
            ->withTimestamps();
    }

    public function tasks()
    {
        return $this->belongsToMany(Task::class, 'telegram_user_tasks')
            ->withPivot('is_submitted', 'is_rewarded', 'submitted_at')
            ->withTimestamps();
    }

    public function referralTasks()
    {
        return $this->belongsToMany(ReferralTask::class, 'telegram_user_referral_task')
            ->withPivot('is_completed')
            ->withTimestamps();
    }

    public function level()
    {
        return $this->belongsTo(Level::class);
    }

    /**
     * Kunlik kirish seriyasi. Saqlashni chaqiruvchi bajaradi.
     */
    public function updateLoginStreak()
    {
        if (!$this->last_login_date?->isToday()) {
            $cap = DailyTask::count();
            $lastClaimedDailyTask = $this->dailyTasks()
                ->orderBy('telegram_user_daily_tasks.created_at', 'desc')
                ->first();

            if (
                $this->last_login_date?->isYesterday()
                && $lastClaimedDailyTask?->pivot?->created_at?->isYesterday()
                && (int) $this->login_streak !== $cap
            ) {
                $this->login_streak = min($this->login_streak + 1, $cap);
            } else {
                $this->login_streak = 1;
                $this->dailyTasks()->detach();
            }
        }
    }

    /**
     * Balansga tanga qo'shadi (atomik) va darajani tekshiradi.
     */
    public function addBalance(int $amount): void
    {
        if ($amount <= 0) {
            return;
        }

        $this->increment('balance', $amount);
        $this->applyLevelUp();
    }

    /**
     * Balans yetarli bo'lsa, darajani oshiradi (max_energy, earn_per_tap) va
     * taklif qilgan do'stga bonus beradi.
     */
    public function applyLevelUp(): void
    {
        $currentNo = (int) (Level::find($this->level_id)?->level ?? 0);

        $newLevels = Level::query()
            ->where('from_balance', '<=', $this->balance)
            ->where('level', '>', $currentNo)
            ->orderByDesc('level')
            ->get();

        $top = $newLevels->first();
        if (!$top) {
            return;
        }

        $levelUp = config('clicker.level_up');

        $this->level_id = $top->id;
        $this->max_energy += $newLevels->count() * $levelUp['max_energy'];
        $this->earn_per_tap += $newLevels->count() * $levelUp['earn_per_tap'];
        $this->saveQuietly();

        if (!$this->referred_by) {
            return;
        }

        $referrer = self::where('telegram_id', $this->referred_by)->first();
        if (!$referrer) {
            return;
        }

        $table = config('clicker.referral.' . ($this->is_premium ? 'premium' : 'base') . '.levelUp', []);
        $bonus = 0;
        foreach ($newLevels as $lvl) {
            $bonus += (int) ($table[(string) $lvl->level] ?? 0);
        }

        if ($bonus > 0) {
            $referrer->addBalance($bonus);
        }
    }

    /**
     * Oflayn paytdagi pul (maks. 3 soat). Bir vaqtning o'zida ko'p so'rov yuborib
     * ikki marta olib bo'lmasligi uchun qator qulflanadi.
     */
    public function calcPassiveEarning(): int
    {
        $earned = DB::transaction(function () {
            $fresh = self::whereKey($this->getKey())->lockForUpdate()->first();

            $base = $fresh->last_passive_at ?? $fresh->last_login_date;
            $earned = 0;

            if ($base && $fresh->production_per_hour > 0) {
                $seconds = max(0, now()->timestamp - $base->timestamp);
                $seconds = min($seconds, 3 * 60 * 60);
                $earned = (int) floor($fresh->production_per_hour / 3600 * $seconds);
            }

            $fresh->last_passive_at = now();
            $fresh->saveQuietly();

            if ($earned > 0) {
                $fresh->increment('balance', $earned);
            }

            return $earned;
        });

        $this->refresh();

        if ($earned > 0) {
            $this->applyLevelUp();
        }

        return $earned;
    }

    /**
     * Har bir bosish `earn_per_tap` energiya sarflaydi va `earn_per_tap` tanga beradi
     * (frontend ham xuddi shunday hisoblaydi). Chaqiruvchi qatorni qulflagan bo'lishi kerak.
     */
    public function tap($count = 1)
    {
        $this->restoreEnergy();

        $perTap = max(1, (int) $this->earn_per_tap);
        $taps = min((int) $count, intdiv((int) $this->available_energy, $perTap));

        if ($taps <= 0) {
            return 0;
        }

        $multiplier = $this->getActiveBoosterMultiplier();
        $earned = $taps * $perTap * $multiplier;

        $this->balance += $earned;
        $this->available_energy -= $taps * $perTap;
        $this->last_tap_date = now();
        $this->save();

        return $earned;
    }

    private function getActiveBoosterMultiplier()
    {
        if ($this->booster_pack_active_until && now()->gt($this->booster_pack_active_until)) {
            return 1;
        }
        if ($this->booster_pack_7x) return 7;
        if ($this->booster_pack_3x) return 3;
        if ($this->booster_pack_2x) return 2;
        return 1;
    }

    /**
     * Energiya sekundiga 1 ta tiklanadi (frontend: har 3 soniyada 3).
     */
    public function restoreEnergy()
    {
        $now = now();

        if ((int) $this->available_energy >= (int) $this->max_energy) {
            $this->last_tap_date = $now;
            $this->available_energy = $this->max_energy;
            $this->save();
            return 0;
        }

        $secondsPassed = $this->last_tap_date ? max(0, $now->timestamp - $this->last_tap_date->timestamp) : 0;

        $before = (int) $this->available_energy;
        $this->available_energy = min($before + $secondsPassed, (int) $this->max_energy);
        $this->last_tap_date = $now;
        $this->save();

        return (int) $this->available_energy - $before;
    }

    public function canUseDailyBooster()
    {
        $now = now();

        // Yangi kun boshlangan bo'lsa
        if (!$this->last_daily_booster_use || $this->last_daily_booster_use->copy()->addDay()->lte($now)) {
            return true;
        }

        // Oxirgi ishlatishdan 1 soat o'tgan va 6 martadan kam ishlatilgan bo'lsa
        return $this->daily_booster_uses < 6 && $this->last_daily_booster_use->copy()->addHour()->lte($now);
    }

    public function useDailyBooster()
    {
        if (!$this->canUseDailyBooster()) {
            return false;
        }

        $now = now();

        if (!$this->last_daily_booster_use || $this->last_daily_booster_use->copy()->addDay()->lte($now)) {
            $this->daily_booster_uses = 0;
        }

        $this->daily_booster_uses++;
        $this->last_daily_booster_use = $now;
        $this->available_energy = $this->max_energy;
        $this->last_tap_date = $now;
        $this->save();

        return true;
    }

    public function checkAndResetDailyBooster()
    {
        $now = now();

        if ($this->last_daily_booster_use && $this->last_daily_booster_use->copy()->addDay()->lte($now)) {
            $this->daily_booster_uses = 0;
            $this->last_daily_booster_use = null;
            $this->save();
        }
    }
}
