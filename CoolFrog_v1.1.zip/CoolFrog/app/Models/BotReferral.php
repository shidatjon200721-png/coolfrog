<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Botga "/start ref123" orqali kelgan, lekin hali o'yinga kirmagan foydalanuvchi.
 */
class BotReferral extends Model
{
    protected $primaryKey = 'telegram_id';

    public $incrementing = false;

    protected $keyType = 'int';

    protected $guarded = [];
}
