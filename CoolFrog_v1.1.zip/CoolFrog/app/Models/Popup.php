<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Popup extends Model
{
    use HasFactory;

    protected $guarded = [];

    public function getImageAttribute($value)
    {
        if (!$value) {
            return null;
        }

        if (preg_match('#^https?://#i', $value)) {
            return $value;
        }

        return url('storage/' . ltrim($value, '/'));
    }
}
