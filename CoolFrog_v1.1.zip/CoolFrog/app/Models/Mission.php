<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Mission extends Model
{
    use HasFactory;

    protected $guarded = [];

    public function getImageAttribute($value)
    {
        if (!$value) {
            return null;
        }

        if (preg_match('#^https?://#i', $value)) {
            return $value;
        }

        return url('storage/' . ltrim($value, '/'));
    }

    public function levels()
    {
        return $this->hasMany(MissionLevel::class);
    }

    public function nextLevel()
    {
        return $this->hasOne(MissionLevel::class)
            ->orderBy('level');
    }

    public function type()
    {
        return $this->belongsTo(MissionType::class);
    }
}
