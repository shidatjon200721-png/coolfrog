<?php

namespace App\Console\Commands;

use App\Services\TelegramApi;
use Illuminate\Console\Command;

class TelegramWebhook extends Command
{
    protected $signature = 'telegram:webhook';

    protected $description = 'Telegram webhook va menyu tugmasini (qayta) o\'rnatadi';

    public function handle(TelegramApi $telegram): int
    {
        $secret = (string) config('services.telegram.webhook_secret');
        $appUrl = rtrim((string) config('services.telegram.app_url'), '/') . '/';
        $url = rtrim((string) config('app.url'), '/') . '/api/telegram/webhook/' . $secret;

        $hook = $telegram->setWebhook($url, $secret);
        $this->line('setWebhook: ' . ($hook['ok'] ?? false ? 'OK' : ($hook['description'] ?? 'error')));

        $menu = $telegram->setMenuButton($appUrl);
        $this->line('setChatMenuButton: ' . ($menu['ok'] ?? false ? 'OK' : ($menu['description'] ?? 'error')));

        return ($hook['ok'] ?? false) ? self::SUCCESS : self::FAILURE;
    }
}
