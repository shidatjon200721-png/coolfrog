<?php

namespace App\Observers;

use App\Models\TelegramUser;

class TelegramUserObserver
{
    public function updated(TelegramUser $user): void
    {
        if (!$user->isDirty('balance')) {
            return;
        }

        $user->applyLevelUp();
    }
}
