<?php

namespace App\Providers;

use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        // O'yin API'si: bitta o'yinchiga daqiqasiga 240 ta so'rov (tap har soniyada bo'lishi mumkin)
        RateLimiter::for('game', function (Request $request) {
            return Limit::perMinute(240)->by($request->user()?->getAuthIdentifier() ?: $request->ip());
        });
    }
}
