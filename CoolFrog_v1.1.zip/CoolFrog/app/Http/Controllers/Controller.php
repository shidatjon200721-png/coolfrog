<?php

namespace App\Http\Controllers;

use App\Models\TelegramUser;
use Illuminate\Http\Request;

abstract class Controller
{
    /**
     * Joriy o'yinchining qatorini qulflaydi (DB::transaction ichida chaqiring).
     * Bir vaqtda kelgan so'rovlar orqali balansni ikki marta ishlatib bo'lmaydi.
     */
    protected function lockedUser(Request $request): TelegramUser
    {
        return TelegramUser::whereKey($request->user()->getKey())->lockForUpdate()->firstOrFail();
    }
}
