<?php

namespace App\Http\Controllers;

use App\Models\DailyTask;
use App\Models\Task;
use App\Models\TelegramUser;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function dashboard()
    {
        $userCount = TelegramUser::count();
        $taskCount = Task::count();
        $dailyTaskCount = DailyTask::count();

        return view('dashboard', compact('userCount', 'taskCount', 'dailyTaskCount'));
    }

    public function users()
    {
        $users = TelegramUser::orderByDesc('id')->paginate(50);

        return view('users', compact('users'));
    }

    public function tasks()
    {
        $tasks = Task::orderByDesc('id')->paginate(50);

        return view('tasks', compact('tasks'));
    }

    public function createTask()
    {
        return view('create_task');
    }

    public function storeTask(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'required|string|max:2000',
            'reward_coins' => 'required|integer|min:1',
            'type' => 'required|in:video,other',
            'action_name' => 'required|string|max:100',
            'link' => 'required|url|max:2000',
            'image' => 'nullable|image|max:2048',
        ]);

        if ($request->hasFile('image')) {
            $validated['image'] = $request->file('image')->store('images/tasks', 'public');
        } else {
            unset($validated['image']);
        }

        Task::create($validated);

        return redirect()->route('tasks')->with('success', 'Task created successfully');
    }

    public function deleteTask(Task $task)
    {
        $task->delete();

        return redirect()->route('tasks')->with('success', 'Task deleted successfully');
    }

    public function dailyTasks()
    {
        $dailyTasks = DailyTask::orderBy('required_login_streak')->get();

        return view('daily_tasks', compact('dailyTasks'));
    }

    public function createDailyTask()
    {
        return view('create_daily_task');
    }

    public function storeDailyTask(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string|max:255',
            'required_login_streak' => 'required|integer|min:1|max:365',
            'reward_coins' => 'required|integer|min:1',
        ]);

        DailyTask::create($validated);

        return redirect()->route('daily_tasks')->with('success', 'Daily task created successfully');
    }

    public function deleteDailyTask(DailyTask $dailyTask)
    {
        $dailyTask->delete();

        return redirect()->route('daily_tasks')->with('success', 'Daily task deleted successfully');
    }
}
