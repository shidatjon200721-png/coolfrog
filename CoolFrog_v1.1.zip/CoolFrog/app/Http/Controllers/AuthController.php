<?php

namespace App\Http\Controllers;

use App\Models\BotReferral;
use App\Models\TelegramUser;
use App\Services\TelegramInitData;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AuthController extends Controller
{
    public function telegramUser(Request $request)
    {
        $botToken = (string) config('services.telegram.bot_token');
        $isLocalDev = app()->environment('local') && $botToken === '';

        if ($isLocalDev) {
            // Faqat lokal ishlab chiqish uchun (bot tokeni yo'q va APP_ENV=local).
            $data = $request->validate([
                'telegram_id' => 'required|integer',
                'first_name' => 'required|string|max:255',
                'last_name' => 'nullable|string|max:255',
                'username' => 'nullable|string|max:255',
                'referred_by' => 'nullable',
            ]);
            $tg = [
                'id' => (int) $data['telegram_id'],
                'first_name' => $data['first_name'],
                'last_name' => $data['last_name'] ?? null,
                'username' => $data['username'] ?? null,
                'is_premium' => false,
            ];
            $referrerId = TelegramInitData::referrerFromStartParam('ref' . ($data['referred_by'] ?? ''));
        } else {
            $request->validate(['init_data' => 'required|string|max:4096']);

            $parsed = TelegramInitData::validate((string) $request->input('init_data'), $botToken);
            if ($parsed === null) {
                return response()->json(['message' => 'Invalid Telegram data'], 401);
            }

            $tg = $parsed['user'];
            $referrerId = TelegramInitData::referrerFromStartParam($parsed['start_param']);
        }

        $telegramId = (int) $tg['id'];

        // /start ref123 orqali kelgan (startapp bo'lmagan) referal
        if ($referrerId === null) {
            $pending = BotReferral::find($telegramId);
            if ($pending) {
                $referrerId = (int) $pending->referred_by;
            }
        }

        $isPremium = (bool) ($tg['is_premium'] ?? false);

        $user = DB::transaction(function () use ($tg, $telegramId, $referrerId, $isPremium) {
            $user = TelegramUser::where('telegram_id', $telegramId)->lockForUpdate()->first();

            if ($user) {
                // Ism/username o'zgargan bo'lishi mumkin
                $user->fill([
                    'first_name' => $tg['first_name'] ?? $user->first_name,
                    'last_name' => $tg['last_name'] ?? null,
                    'username' => $tg['username'] ?? null,
                    'is_premium' => $isPremium,
                ])->save();

                return $user;
            }

            $referrer = null;
            if ($referrerId !== null && $referrerId !== $telegramId) {
                $referrer = TelegramUser::where('telegram_id', $referrerId)->first();
            }

            $balance = 5_000;
            if ($referrer) {
                $bonus = (int) config('clicker.referral.' . ($isPremium ? 'premium' : 'base') . '.welcome', 0);
                if ($bonus > 0) {
                    $referrer->increment('balance', $bonus);
                    $balance += $bonus;
                }
            }

            return TelegramUser::create([
                'telegram_id' => $telegramId,
                'first_name' => $tg['first_name'] ?? 'Player',
                'last_name' => $tg['last_name'] ?? null,
                'username' => $tg['username'] ?? null,
                'is_premium' => $isPremium,
                'balance' => $balance,
                'referred_by' => $referrer ? $referrerId : null,
            ]);
        });

        BotReferral::where('telegram_id', $telegramId)->delete();

        $token = $user->createToken((string) $user->telegram_id);

        return response()->json([
            'first_login' => $user->wasRecentlyCreated,
            'telegram_id' => $user->telegram_id,
            'token' => $token->plainTextToken,
        ]);
    }
}
