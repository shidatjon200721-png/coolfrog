<?php

namespace App\Http\Controllers;

use App\Models\ReferralTask;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReferralTaskController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();

        $tasks = ReferralTask::query()
            ->leftJoin('telegram_user_referral_task', function ($join) use ($user) {
                $join->on('referral_tasks.id', '=', 'telegram_user_referral_task.referral_task_id')
                    ->where('telegram_user_referral_task.telegram_user_id', $user->id);
            })
            ->select(['referral_tasks.*', 'telegram_user_referral_task.is_completed'])
            ->get();

        return response()->json($tasks);
    }

    public function complete(Request $request, ReferralTask $task)
    {
        $result = DB::transaction(function () use ($request, $task) {
            $user = $this->lockedUser($request);

            if ($user->referralTasks()->where('referral_tasks.id', $task->id)->exists()) {
                return ['Task already completed.', 400];
            }

            if ($user->referrals()->count() < $task->number_of_referrals) {
                return ['Not enough referrals.', 400];
            }

            $user->referralTasks()->attach($task->id, ['is_completed' => true]);
            $user->addBalance((int) $task->reward);

            return null;
        });

        if ($result !== null) {
            return response()->json(['success' => false, 'message' => $result[0]], 400);
        }

        return response()->json([
            'success' => true,
            'message' => 'Task completed',
        ]);
    }
}
