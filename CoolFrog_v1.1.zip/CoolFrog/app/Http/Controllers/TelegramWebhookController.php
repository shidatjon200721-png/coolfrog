<?php

namespace App\Http\Controllers;

use App\Models\BotReferral;
use App\Models\TelegramUser;
use App\Services\TelegramApi;
use App\Services\TelegramInitData;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

/**
 * Telegram bot — webhook orqali ishlaydi. Alohida server/pm2/Node kerak emas.
 * Oldingi bot/index.ts dagi "/start" xatti-harakati shu yerda qayta yozilgan.
 */
class TelegramWebhookController extends Controller
{
    public function handle(Request $request, string $secret, TelegramApi $telegram)
    {
        $expected = (string) config('services.telegram.webhook_secret');

        // URL'dagi maxfiy qism va Telegram yuboradigan sarlavha — ikkalasi ham mos kelishi shart.
        if (
            $expected === ''
            || !hash_equals($expected, $secret)
            || !hash_equals($expected, (string) $request->header('X-Telegram-Bot-Api-Secret-Token'))
        ) {
            abort(404);
        }

        try {
            $this->processUpdate($request->json()->all(), $telegram);
        } catch (\Throwable $e) {
            // Telegram qayta-qayta yubormasligi uchun doim 200 qaytaramiz.
            Log::error('Telegram webhook error: ' . $e->getMessage());
        }

        return response()->json(['ok' => true]);
    }

    private function processUpdate(array $update, TelegramApi $telegram): void
    {
        $message = $update['message'] ?? null;
        if (!is_array($message) || ($message['chat']['type'] ?? null) !== 'private') {
            return;
        }

        $text = trim((string) ($message['text'] ?? ''));
        $chatId = (int) ($message['chat']['id'] ?? 0);
        $fromId = (int) ($message['from']['id'] ?? 0);

        if ($chatId === 0 || $fromId === 0 || $text === '') {
            return;
        }

        if (!preg_match('#^/(start|play)(?:@\w+)?(?:\s+(\S+))?$#i', $text, $m)) {
            return;
        }

        $payload = $m[2] ?? null;
        $referrerId = TelegramInitData::referrerFromStartParam($payload);

        // "/start ref123": do'st hali o'yinga kirmagan bo'lsa, taklif qilgan odamni eslab qolamiz.
        if ($referrerId !== null && $referrerId !== $fromId) {
            $alreadyPlayer = TelegramUser::where('telegram_id', $fromId)->exists();
            $referrerExists = TelegramUser::where('telegram_id', $referrerId)->exists();

            if (!$alreadyPlayer && $referrerExists) {
                BotReferral::updateOrCreate(['telegram_id' => $fromId], ['referred_by' => $referrerId]);
            }
        }

        $telegram->sendPlayButton(
            $chatId,
            'Play Cool Frog!',
            'Play Game',
            rtrim((string) config('services.telegram.app_url'), '/') . '/'
        );
    }
}
