<?php

namespace App\Http\Controllers;

use App\Models\TelegramUser;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class TelegramUserController extends Controller
{
    public function referredUsers(Request $request)
    {
        $user = $request->user();

        $perPage = min(max((int) ($request->get('per_page') ?? 10), 1), 50);

        $referredUsers = TelegramUser::query()
            ->select(TelegramUser::PUBLIC_COLUMNS)
            ->with('level')
            ->where('referred_by', $user->telegram_id)
            ->orderByDesc('id')
            ->paginate($perPage);

        return JsonResource::collection($referredUsers);
    }
}
