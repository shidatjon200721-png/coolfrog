<?php

namespace App\Http\Controllers;

use App\Models\Task;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserTaskController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();

        $tasks = Task::query()
            ->leftJoin('telegram_user_tasks', function ($join) use ($user) {
                $join->on('tasks.id', '=', 'telegram_user_tasks.task_id')
                    ->where('telegram_user_tasks.telegram_user_id', $user->id);
            })
            ->select(['tasks.*', 'telegram_user_tasks.is_submitted', 'telegram_user_tasks.is_rewarded', 'telegram_user_tasks.submitted_at'])
            ->get()
            ->map(function ($task) {
                return array_merge($task->toArray(), [
                    'submitted_at' => $task->submitted_at ? Carbon::parse($task->submitted_at)->toIso8601String() : null,
                ]);
            });

        return response()->json($tasks);
    }

    public function store(Request $request, Task $task)
    {
        $user = $request->user();

        if ($user->tasks()->where('task_id', $task->id)->exists()) {
            return response()->json(['success' => false, 'message' => 'Task already submitted.'], 400);
        }

        try {
            $user->tasks()->attach($task->id, ['is_submitted' => true, 'submitted_at' => now()]);
        } catch (\Illuminate\Database\UniqueConstraintViolationException $e) {
            // Bir vaqtda ikki marta bosilgan
            return response()->json(['success' => false, 'message' => 'Task already submitted.'], 400);
        }

        return response()->json([
            'success' => true,
            'message' => 'Task submitted successfully. Waiting for approval.',
        ]);
    }

    public function claim(Request $request, Task $task)
    {
        $delay = (int) config('clicker.task_claim_delay_minutes', 60);

        $result = DB::transaction(function () use ($request, $task, $delay) {
            $user = $this->lockedUser($request);

            $row = DB::table('telegram_user_tasks')
                ->where('telegram_user_id', $user->id)
                ->where('task_id', $task->id)
                ->lockForUpdate()
                ->first();

            if (!$row) {
                return ['Task not found.', 404];
            }

            if ($row->is_rewarded) {
                return ['Task already rewarded.', 400];
            }

            // Frontend ham shuncha kutadi; server tomonda ham majburiy.
            if (!$row->submitted_at || Carbon::parse($row->submitted_at)->addMinutes($delay)->isFuture()) {
                return ['Task is not ready to be claimed yet.', 400];
            }

            DB::table('telegram_user_tasks')->where('id', $row->id)->update([
                'is_rewarded' => true,
                'updated_at' => now(),
            ]);

            $user->addBalance((int) $task->reward_coins);

            return null;
        });

        if ($result !== null) {
            return response()->json(['success' => false, 'message' => $result[0]], $result[1]);
        }

        return response()->json([
            'success' => true,
            'message' => "You have successfully claimed {$task->reward_coins} from {$task->name}.",
        ]);
    }
}
