<?php

namespace App\Http\Controllers;

use App\Models\Mission;
use App\Models\MissionLevel;
use App\Models\TelegramUser;
use App\Models\TelegramUserMission;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserMissionController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();

        $missions = Mission::query()
            ->with(['nextLevel' => fn ($q) => $q->whereNotIn(
                'id',
                fn ($q) =>
                $q->select('mission_level_id')
                    ->from('telegram_user_missions')
                    ->where('telegram_user_id', $user->id)
            )])
            ->withSum(['levels as production_per_hour' => fn ($q) => $q->whereIn(
                'id',
                fn ($q) =>
                $q->select('mission_level_id')
                    ->from('telegram_user_missions')
                    ->where('telegram_user_id', $user->id)
            )], 'production_per_hour')
            ->when($request->get('type'), fn ($q) => $q->where('missions.mission_type_id', $request->get('type')))
            ->get();

        return response()->json($missions);
    }

    public function store(Request $request, MissionLevel $missionLevel)
    {
        $missionLevel->load('mission');
        $mission = $missionLevel->mission;

        $error = null;
        $user = null;

        DB::transaction(function () use ($request, $missionLevel, $mission, &$error, &$user) {
            $user = $this->lockedUser($request);
            $user->load('level');

            // Faqat navbatdagi darajani sotib olish mumkin (1, 2, 3 ...)
            $bought = TelegramUserMission::query()
                ->where('telegram_user_id', $user->id)
                ->whereIn('mission_level_id', MissionLevel::where('mission_id', $mission->id)->select('id'))
                ->max('level') ?? 0;

            if ((int) $missionLevel->level !== (int) $bought + 1) {
                $error = ['Invalid mission level', 400];
                return;
            }

            if ($mission->required_user_level && $mission->required_user_level > (int) ($user->level->level ?? 0)) {
                $error = ['Your level is too low for this mission', 403];
                return;
            }

            if (
                $mission->required_friends_invitation
                && $mission->required_friends_invitation > TelegramUser::where('referred_by', $user->telegram_id)->count()
            ) {
                $error = ['Invite more friends to unlock this mission', 403];
                return;
            }

            if ($user->balance < $missionLevel->cost) {
                $error = ['Insufficient balance', 400];
                return;
            }

            TelegramUserMission::create([
                'telegram_user_id' => $user->id,
                'mission_level_id' => $missionLevel->id,
                'level' => $missionLevel->level,
            ]);

            $user->production_per_hour += $missionLevel->production_per_hour;
            $user->balance -= $missionLevel->cost;
            $user->save();
        });

        if ($error) {
            return response()->json(['message' => $error[0]], $error[1]);
        }

        $nextLevel = MissionLevel::query()
            ->where('mission_id', $missionLevel->mission_id)
            ->where('level', $missionLevel->level + 1)
            ->first();

        return response()->json([
            'message' => "Mission {$mission->name} upgraded {$missionLevel->level} level",
            'next_level' => $nextLevel,
            'user' => $user,
        ]);
    }
}
