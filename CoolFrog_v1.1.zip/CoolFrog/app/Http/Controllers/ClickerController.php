<?php

namespace App\Http\Controllers;

use App\Models\DailyTask;
use App\Models\Level;
use App\Models\MissionType;
use App\Models\TelegramUser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ClickerController extends Controller
{
    private const BOOSTER_BASE_COST = 1000;

    public function sync(Request $request)
    {
        $user = $request->user();

        // Oflayn daromad (qator qulflanadi, qayta-qayta so'rab ko'paytirib bo'lmaydi)
        $passiveEarnings = $user->calcPassiveEarning();

        $user->updateLoginStreak();
        $user->checkAndResetDailyBooster();
        $restoredEnergy = $user->restoreEnergy();

        $user->last_login_date = now();
        $user->save();

        $user->load('level');

        $canUseDailyBooster = $user->canUseDailyBooster();
        $levels = Level::orderBy('level')->get();

        return response()->json([
            'user' => $user,
            'restored_energy' => $restoredEnergy,
            'boosters' => [
                'multi_tap' => [
                    'level' => $user->multi_tap_level,
                    'cost' => $this->getBoosterCost($user, 'multi_tap'),
                    'increase_by' => 1,
                ],
                'energy_limit' => [
                    'level' => $user->energy_limit_level,
                    'cost' => $this->getBoosterCost($user, 'energy_limit'),
                    'increase_by' => 500,
                ],
            ],
            'daily_booster' => [
                'can_use' => $canUseDailyBooster,
                'uses_today' => $user->daily_booster_uses,
                'next_available_at' => $canUseDailyBooster
                    ? now()
                    : ($user->last_daily_booster_use ? $user->last_daily_booster_use->copy()->addHour() : null),
            ],
            'total_daily_rewards' => DailyTask::sum('reward_coins'),
            'levels' => $levels,
            'max_level' => $levels->max('level'),
            'level_up' => config('clicker.level_up'),
            'referral' => config('clicker.referral'),
            'mission_types' => MissionType::all(),
            'passive_earnings' => $passiveEarnings,
            'total_referals' => TelegramUser::where('referred_by', $user->telegram_id)->count(),
        ]);
    }

    public function tap(Request $request)
    {
        $validated = $request->validate([
            'count' => 'required|integer|min:1|max:10000',
        ]);

        $levelBefore = (int) $request->user()->level_id;

        $user = DB::transaction(function () use ($request, $validated) {
            $user = $this->lockedUser($request);
            $user->tap($validated['count']);

            return $user;
        });

        $user->refresh()->load('level');
        $leveledUp = (int) $user->level_id !== $levelBefore;

        return response()->json([
            'success' => true,
            'balance' => $user->balance,
            'available_energy' => $user->available_energy,
            'leveled_up' => $leveledUp,
            'level' => $user->level,
            'earn_per_tap' => $user->earn_per_tap,
            'max_energy' => $user->max_energy,
        ]);
    }

    public function buyBooster(Request $request)
    {
        $request->validate([
            'booster_type' => 'required|in:multi_tap,energy_limit',
        ]);

        $boosterType = $request->input('booster_type');

        $result = DB::transaction(function () use ($request, $boosterType) {
            $user = $this->lockedUser($request);
            $cost = $this->getBoosterCost($user, $boosterType);

            if ($user->balance < $cost) {
                return null;
            }

            $user->balance -= $cost;

            if ($boosterType === 'multi_tap') {
                $user->multi_tap_level++;
                $user->earn_per_tap++;
            } else {
                $user->energy_limit_level++;
                $user->max_energy += 500;
            }

            $user->save();

            return $user;
        });

        if ($result === null) {
            return response()->json([
                'success' => false,
                'message' => 'Insufficient balance',
            ], 400);
        }

        $user = $result;

        return response()->json([
            'success' => true,
            'message' => 'Booster purchased successfully',
            'balance' => $user->balance,
            'earn_per_tap' => $user->earn_per_tap,
            'max_energy' => $user->max_energy,
            'multi_tap_level' => $user->multi_tap_level,
            'energy_limit_level' => $user->energy_limit_level,
            'next_multi_tap_cost' => $this->getBoosterCost($user, 'multi_tap'),
            'next_energy_limit_cost' => $this->getBoosterCost($user, 'energy_limit'),
        ]);
    }

    /**
     * Narx: 1000, 2000, 4000, ... (frontend ham shu formula bilan hisoblaydi).
     */
    private function getBoosterCost($user, $boosterType): int
    {
        $level = $boosterType === 'multi_tap' ? $user->multi_tap_level : $user->energy_limit_level;

        return self::BOOSTER_BASE_COST * (2 ** min(max((int) $level - 1, 0), 40));
    }

    public function listDailyTasks(Request $request)
    {
        $user = $request->user();

        $dailyTasks = DailyTask::query()
            ->leftJoin('telegram_user_daily_tasks', function ($join) use ($user) {
                $join->on('daily_tasks.id', '=', 'telegram_user_daily_tasks.daily_task_id')
                    ->where('telegram_user_daily_tasks.telegram_user_id', $user->id);
            })
            ->select(['daily_tasks.*', 'telegram_user_daily_tasks.completed'])
            ->selectRaw('daily_tasks.required_login_streak <= ? as available', [$user->login_streak])
            ->orderBy('daily_tasks.required_login_streak')
            ->get();

        return response()->json($dailyTasks);
    }

    public function listLeaderboard(Request $request)
    {
        $request->validate([
            'level_id' => 'required|integer|exists:levels,id',
        ]);

        $topUsers = TelegramUser::query()
            ->select(TelegramUser::PUBLIC_COLUMNS)
            ->where('level_id', $request->input('level_id'))
            ->orderBy('production_per_hour', 'desc')
            ->orderBy('id')
            ->take(100)
            ->get();

        return response()->json($topUsers);
    }

    public function useDailyBooster(Request $request)
    {
        [$user, $used] = DB::transaction(function () use ($request) {
            $user = $this->lockedUser($request);
            $used = $user->useDailyBooster();

            return [$user, $used];
        });

        if ($used) {
            return response()->json([
                'success' => true,
                'message' => 'Daily booster used successfully',
                'current_energy' => $user->max_energy,
                'daily_booster_uses' => $user->daily_booster_uses,
                'next_available_at' => $user->last_daily_booster_use->copy()->addHour(),
            ]);
        }

        return response()->json([
            'success' => false,
            'message' => 'Cannot use daily booster at this time',
            'daily_booster_uses' => $user->daily_booster_uses,
            'next_available_at' => $user->last_daily_booster_use ? $user->last_daily_booster_use->copy()->addHour() : null,
        ], 400);
    }

    public function claimDailyTaskReward(Request $request)
    {
        $reward = DB::transaction(function () use ($request) {
            $user = $this->lockedUser($request);

            $task = DailyTask::where('required_login_streak', '<=', $user->login_streak)
                ->whereDoesntHave('telegramUsers', function ($query) use ($user) {
                    $query->where('telegram_user_id', $user->id);
                })
                ->orderBy('required_login_streak')
                ->first();

            if (!$task) {
                return null;
            }

            $user->dailyTasks()->attach($task->id, ['completed' => true]);
            $user->addBalance((int) $task->reward_coins);

            return $user->fresh()->balance;
        });

        if ($reward === null) {
            return response()->json([
                'success' => false,
                'message' => 'Unable to claim daily task reward. Task may not be available or already completed for today.',
            ], 400);
        }

        return response()->json([
            'success' => true,
            'message' => 'Daily task reward claimed successfully',
            'balance' => $reward,
        ]);
    }

    public function setTonWallet(Request $request)
    {
        $request->validate([
            'ton_wallet' => ['required', 'string', 'regex:/^[A-Za-z0-9_\-:]{40,70}$/'],
        ]);

        $user = $request->user();
        $user->ton_wallet = $request->input('ton_wallet');
        $user->save();

        return response()->json([
            'success' => true,
            'message' => 'TON Wallet address updated successfully',
            'ton_wallet' => $user->ton_wallet,
        ]);
    }
}
