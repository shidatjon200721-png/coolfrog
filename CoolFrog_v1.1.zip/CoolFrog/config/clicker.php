<?php

return [
    // Vazifani topshirgandan keyin mukofotni olish uchun kutish vaqti (frontend ham 60 daqiqa kutadi)
    'task_claim_delay_minutes' => 60,

    'level_up' => [
        'max_energy' => 500,
        'earn_per_tap' => 1,
    ],
    'referral' => [
        "base" => [
            "welcome" => 5000,
            "levelUp" => [
                "1" => 0,
                "2" => 0,
                "3" => 0,
                "4" => 7_000,
                "5" => 0,
                "6" => 10_000,
                "7" => 0,
                "9" => 15_000,
                "10" => 0,
                "11" => 0,
                "12" => 20_000,
                "13" => 0,
                "14" => 30_000,
                "15" => 0,
                "16" => 40_000,
                "17" => 0,
                "18" => 50_000,
            ]
        ],
        "premium" => [
            "welcome" => 25000,
            "levelUp" => [
                "1" => 0,
                "2" => 0,
                "3" => 0,
                "4" => 30_000,
                "5" => 0,
                "6" => 40_000,
                "7" => 0,
                "9" => 50_000,
                "10" => 0,
                "11" => 0,
                "12" => 75_000,
                "13" => 0,
                "14" => 100_000,
                "15" => 0,
                "16" => 125_000,
                "17" => 0,
                "18" => 150_000,
            ]
        ]
    ],
    // 'referral_tasks' => [
    //     ['number_of_friends' => 3, 'reward' => 25_000],
    //     ['number_of_friends' => 6, 'reward' => 50_000],
    // ]
];
