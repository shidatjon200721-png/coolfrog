<?php
/**
 * CoolFrog — veb o'rnatuvchi.
 *
 * Brauzerda oching:  https://SIZNING-DOMEN/install.php
 * (SSH, composer, npm, pm2 yoki Node kerak emas — bot ham shu yerdan PHP webhook bilan ishga tushadi.)
 *
 * O'rnatishdan so'ng bu fayl o'zini bloklaydi (storage/installed.lock) va uni o'chirib tashlash tavsiya etiladi.
 */

declare(strict_types=1);

@set_time_limit(600);
@ini_set('display_errors', '1');
error_reporting(E_ALL);

// Loyiha ildizi: install.php ildizda ham, public/ ichida ham (shim orqali) ishlaydi.
$ROOT = is_file(__DIR__ . '/artisan') ? __DIR__ : dirname(__DIR__);
$PUBLIC = $ROOT . '/public';
$LOCK = $ROOT . '/storage/installed.lock';

function e(?string $s): string
{
    return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
}

function envValue(string $v): string
{
    return '"' . str_replace(['\\', '"'], ['\\\\', '\\"'], $v) . '"';
}

function detectBaseUrl(): string
{
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
        || (($_SERVER['HTTP_CF_VISITOR'] ?? '') !== '' && str_contains($_SERVER['HTTP_CF_VISITOR'], 'https'));
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';

    return ($https ? 'https' : 'http') . '://' . $host;
}

function curlJson(string $url, ?array $payload = null): array
{
    if (!function_exists('curl_init')) {
        return ['ok' => false, 'description' => 'PHP curl kengaytmasi yoqilmagan'];
    }
    $ch = curl_init($url);
    $opts = [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 20, CURLOPT_CONNECTTIMEOUT => 10];
    if ($payload !== null) {
        $opts[CURLOPT_POST] = true;
        $opts[CURLOPT_HTTPHEADER] = ['Content-Type: application/json'];
        $opts[CURLOPT_POSTFIELDS] = json_encode($payload);
    }
    curl_setopt_array($ch, $opts);
    $res = curl_exec($ch);
    $err = curl_error($ch);
    curl_close($ch);
    if ($res === false) {
        return ['ok' => false, 'description' => 'Ulanib bo\'lmadi: ' . $err];
    }
    $json = json_decode((string) $res, true);

    return is_array($json) ? $json : ['ok' => false, 'description' => 'Telegram noto\'g\'ri javob qaytardi'];
}

function rrmdirContents(string $dir): void
{
    if (!is_dir($dir)) {
        return;
    }
    foreach (scandir($dir) ?: [] as $f) {
        if ($f === '.' || $f === '..' || $f === '.gitignore') {
            continue;
        }
        $p = $dir . '/' . $f;
        is_dir($p) && !is_link($p) ? (rrmdirContents($p) || @rmdir($p)) : @unlink($p);
    }
}

function copyDir(string $src, string $dst): void
{
    @mkdir($dst, 0755, true);
    foreach (scandir($src) ?: [] as $f) {
        if ($f === '.' || $f === '..' || $f === '.gitignore') {
            continue;
        }
        is_dir("$src/$f") ? copyDir("$src/$f", "$dst/$f") : @copy("$src/$f", "$dst/$f");
    }
}

function findPhpCli(): ?string
{
    $candidates = array_filter([
        defined('PHP_BINDIR') ? PHP_BINDIR . '/php' : null,
        '/usr/local/bin/php', '/usr/bin/php', '/opt/cpanel/ea-php82/root/usr/bin/php',
        '/opt/cpanel/ea-php83/root/usr/bin/php', 'php',
    ]);
    foreach ($candidates as $bin) {
        $out = [];
        $code = 1;
        @exec(escapeshellarg($bin) . ' -r "echo PHP_VERSION_ID;" 2>&1', $out, $code);
        if ($code === 0 && isset($out[0]) && (int) $out[0] >= 80200) {
            return $bin;
        }
    }

    return null;
}

function requirements(string $root, string $public): array
{
    $r = [];
    $r[] = ['PHP 8.2 yoki yuqori (hozir ' . PHP_VERSION . ')', PHP_VERSION_ID >= 80200, true];
    foreach (['pdo_mysql', 'mbstring', 'openssl', 'tokenizer', 'xml', 'ctype', 'json', 'fileinfo', 'curl'] as $ext) {
        $r[] = ["PHP kengaytma: $ext", extension_loaded($ext), true];
    }
    $r[] = ['Yoziladigan: storage/', is_writable($root . '/storage'), true];
    $r[] = ['Yoziladigan: bootstrap/cache/', is_writable($root . '/bootstrap/cache'), true];
    $r[] = ['Yoziladigan: loyiha papkasi (.env uchun)', is_writable($root), true];
    $r[] = ['Yoziladigan: public/ (config.js uchun)', is_writable($public), true];
    $r[] = ['vendor/ (Laravel kutubxonalari) mavjud', is_file($root . '/vendor/autoload.php'), true];
    $r[] = ["O'yin frontendi yig'ilgan (public/index.html)", is_file($public . '/index.html'), false];

    return $r;
}

$errors = [];
$log = [];
$done = false;
$installed = is_file($LOCK);
$action = $_SERVER['REQUEST_METHOD'] === 'POST' ? (string) ($_POST['action'] ?? '') : '';

$in = [
    'app_url' => rtrim((string) ($_POST['app_url'] ?? detectBaseUrl()), '/'),
    'db_host' => (string) ($_POST['db_host'] ?? 'localhost'),
    'db_port' => (string) ($_POST['db_port'] ?? '3306'),
    'db_name' => (string) ($_POST['db_name'] ?? ''),
    'db_user' => (string) ($_POST['db_user'] ?? ''),
    'db_pass' => (string) ($_POST['db_pass'] ?? ''),
    'bot_token' => trim((string) ($_POST['bot_token'] ?? '')),
    'mini_app' => trim((string) ($_POST['mini_app'] ?? '')),
    'admin_name' => (string) ($_POST['admin_name'] ?? 'Admin'),
    'admin_email' => trim((string) ($_POST['admin_email'] ?? '')),
    'admin_pass' => (string) ($_POST['admin_pass'] ?? ''),
    'sample' => isset($_POST['action']) ? isset($_POST['sample']) : true,
    'force' => isset($_POST['force']),
];

/* ---------- Kutubxonalarni composer bilan o'rnatish ---------- */
if ($action === 'composer' && !$installed) {
    $php = findPhpCli();
    if (!function_exists('proc_open') || $php === null) {
        $errors[] = "Serverda proc_open/PHP-CLI mavjud emas. vendor/ papkasini kompyuteringizda `composer install --no-dev` bilan yig'ib, hostingga yuklang (README.md ga qarang) yoki tayyor ZIP (GitHub Actions) dan foydalaning.";
    } else {
        $phar = $ROOT . '/storage/composer.phar';
        if (!is_file($phar)) {
            $data = null;
            if (function_exists('curl_init')) {
                $ch = curl_init('https://getcomposer.org/download/latest-stable/composer.phar');
                curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true, CURLOPT_TIMEOUT => 120]);
                $data = curl_exec($ch);
                curl_close($ch);
            }
            if (is_string($data) && strlen($data) > 1000000) {
                file_put_contents($phar, $data);
            } else {
                $errors[] = 'composer.phar ni yuklab bo\'lmadi (getcomposer.org ga chiqish yopiq bo\'lishi mumkin).';
            }
        }
        if (!$errors) {
            @mkdir($ROOT . '/storage/composer-home', 0755, true);
            $cmd = escapeshellarg($php) . ' -d memory_limit=-1 ' . escapeshellarg($phar)
                . ' install --no-dev --no-interaction --no-scripts --prefer-dist --optimize-autoloader 2>&1';
            $proc = proc_open($cmd, [1 => ['pipe', 'w']], $pipes, $ROOT, [
                'COMPOSER_HOME' => $ROOT . '/storage/composer-home',
                'COMPOSER_ALLOW_SUPERUSER' => '1',
                'HOME' => $ROOT . '/storage/composer-home',
                'PATH' => getenv('PATH') ?: '/usr/local/bin:/usr/bin:/bin',
            ]);
            $out = is_resource($proc) ? stream_get_contents($pipes[1]) : 'proc_open ishlamadi';
            if (is_resource($proc)) {
                $code = proc_close($proc);
            } else {
                $code = 1;
            }
            $log[] = "composer install (kod $code):\n" . substr((string) $out, -4000);
            if (!is_file($ROOT . '/vendor/autoload.php')) {
                $errors[] = 'composer install muvaffaqiyatsiz tugadi (yuqoridagi logga qarang).';
            }
        }
    }
}

/* ---------- Asosiy o'rnatish ---------- */
if ($action === 'install' && !$installed) {
    if (!is_file($ROOT . '/vendor/autoload.php')) {
        $errors[] = 'vendor/ papkasi yo\'q — avval "Kutubxonalarni o\'rnatish" tugmasini bosing yoki vendor/ ni yuklang.';
    }
    if (!preg_match('#^https?://[^\s/]+$#i', $in['app_url'])) {
        $errors[] = 'Sayt manzili noto\'g\'ri. Namuna: https://oyin.example.com (oxirida "/" va papka bo\'lmasin).';
    }
    if ($in['db_name'] === '' || $in['db_user'] === '') {
        $errors[] = 'Ma\'lumotlar bazasi nomi va foydalanuvchisini kiriting.';
    }
    if (!preg_match('/^\d{6,12}:[A-Za-z0-9_-]{30,}$/', $in['bot_token'])) {
        $errors[] = 'Bot tokeni noto\'g\'ri ko\'rinadi (BotFather bergan "123456:ABC..." shaklida bo\'lsin).';
    }
    if (!filter_var($in['admin_email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Admin email noto\'g\'ri.';
    }
    if (strlen($in['admin_pass']) < 8) {
        $errors[] = 'Admin paroli kamida 8 belgi bo\'lsin.';
    }
    if ($in['mini_app'] !== '' && !preg_match('/^[A-Za-z0-9_]{3,64}$/', $in['mini_app'])) {
        $errors[] = 'Mini App qisqa nomi faqat lotin harf, raqam va "_" dan iborat bo\'lsin.';
    }

    $pdo = null;
    if (!$errors) {
        try {
            $pdo = new PDO(
                "mysql:host={$in['db_host']};port={$in['db_port']};dbname={$in['db_name']};charset=utf8mb4",
                $in['db_user'],
                $in['db_pass'],
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_TIMEOUT => 10]
            );
            $log[] = '✔ Ma\'lumotlar bazasiga ulanish muvaffaqiyatli';
            $exists = $pdo->query("SHOW TABLES LIKE 'telegram_users'")->fetchColumn();
            if ($exists && !$in['force']) {
                $errors[] = 'Bazada o\'yin jadvallari allaqachon bor. Ularni o\'chirib qayta o\'rnatish uchun "Mavjud jadvallarni o\'chirish" katagini belgilang.';
            }
        } catch (Throwable $ex) {
            $errors[] = 'Bazaga ulanib bo\'lmadi: ' . $ex->getMessage();
        }
    }

    // Telegram tokenini tekshirish (webhook sozlashdan oldin)
    $botUsername = '';
    if (!$errors) {
        $me = curlJson("https://api.telegram.org/bot{$in['bot_token']}/getMe");
        if (!($me['ok'] ?? false)) {
            $errors[] = 'Telegram bot tokeni qabul qilinmadi: ' . ($me['description'] ?? 'noma\'lum xato');
        } else {
            $botUsername = (string) ($me['result']['username'] ?? '');
            $log[] = "✔ Bot topildi: @{$botUsername}";
        }
    }

    if (!$errors) {
        try {
            // 1) .env
            $secret = bin2hex(random_bytes(24));
            $key = 'base64:' . base64_encode(random_bytes(32));
            $env = [
                'APP_NAME' => 'Cool Frog', 'APP_ENV' => 'production', 'APP_KEY' => $key, 'APP_DEBUG' => 'false',
                'APP_TIMEZONE' => 'UTC', 'APP_URL' => $in['app_url'], 'APP_LOCALE' => 'en', 'APP_FALLBACK_LOCALE' => 'en',
                'BCRYPT_ROUNDS' => '12', 'LOG_CHANNEL' => 'single', 'LOG_LEVEL' => 'warning',
                'DB_CONNECTION' => 'mysql', 'DB_HOST' => $in['db_host'], 'DB_PORT' => $in['db_port'],
                'DB_DATABASE' => $in['db_name'], 'DB_USERNAME' => $in['db_user'], 'DB_PASSWORD' => $in['db_pass'],
                'SESSION_DRIVER' => 'file', 'SESSION_LIFETIME' => '120', 'CACHE_STORE' => 'file',
                'QUEUE_CONNECTION' => 'sync', 'FILESYSTEM_DISK' => 'local', 'MAIL_MAILER' => 'log',
                'TELEGRAM_BOT_TOKEN' => $in['bot_token'], 'TELEGRAM_BOT_USERNAME' => $botUsername,
                'TELEGRAM_WEBHOOK_SECRET' => $secret, 'FRONTEND_URL' => $in['app_url'],
            ];
            $lines = [];
            foreach ($env as $k => $v) {
                $lines[] = $k . '=' . envValue((string) $v);
            }
            if (file_put_contents($ROOT . '/.env', implode("\n", $lines) . "\n") === false) {
                throw new RuntimeException('.env faylini yozib bo\'lmadi (ruxsatlarni tekshiring).');
            }
            @chmod($ROOT . '/.env', 0640);
            $log[] = '✔ .env yaratildi (yangi APP_KEY bilan)';

            // 2) Laravel
            foreach (glob($ROOT . '/bootstrap/cache/*.php') ?: [] as $f) {
                @unlink($f);
            }
            rrmdirContents($ROOT . '/storage/framework/views');
            foreach (['app/public', 'framework/cache/data', 'framework/sessions', 'framework/views', 'logs'] as $d) {
                @mkdir($ROOT . '/storage/' . $d, 0755, true);
            }

            require $ROOT . '/vendor/autoload.php';
            /** @var \Illuminate\Foundation\Application $app */
            $app = require $ROOT . '/bootstrap/app.php';
            /** @var \Illuminate\Contracts\Console\Kernel $kernel */
            $kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
            $kernel->bootstrap();

            $run = function (string $cmd, array $args = []) use ($kernel, &$log): int {
                $code = $kernel->call($cmd, $args);
                $out = trim($kernel->output());
                $log[] = ($code === 0 ? '✔ ' : '✘ ') . "artisan $cmd" . ($out !== '' ? "\n" . substr($out, -1500) : '');

                return $code;
            };

            $run('package:discover');

            $migrateCode = $run($exists ?? false ? 'migrate:fresh' : 'migrate', ['--force' => true]);
            if ($migrateCode !== 0) {
                throw new RuntimeException('Migratsiya muvaffaqiyatsiz tugadi.');
            }

            $seeders = ['LevelSeeder', 'DailyTaskSeeder', 'MissionTypeSeeder', 'MissionSeeder', 'ReferralTaskSeeder'];
            if ($in['sample']) {
                $seeders[] = 'TaskSeeder';
                $seeders[] = 'PopupSeeder';
            }
            foreach ($seeders as $seeder) {
                if ($run('db:seed', ['--class' => 'Database\\Seeders\\' . $seeder, '--force' => true]) !== 0) {
                    throw new RuntimeException("Seeder ishlamadi: $seeder");
                }
            }

            // 3) Admin
            \App\Models\User::updateOrCreate(
                ['email' => $in['admin_email']],
                ['name' => $in['admin_name'] ?: 'Admin', 'password' => $in['admin_pass'], 'email_verified_at' => now()]
            );
            $log[] = '✔ Admin yaratildi: ' . $in['admin_email'];

            // 4) storage:link (symlink bo'lmasa — nusxa)
            $link = $PUBLIC . '/storage';
            if (!is_link($link) && !is_dir($link)) {
                if (!@symlink($ROOT . '/storage/app/public', $link)) {
                    copyDir($ROOT . '/storage/app/public', $link);
                    $log[] = '⚠ symlink ruxsat etilmadi — rasmlar nusxalandi (admin orqali yuklangan yangi rasmlar ko\'rinmasligi mumkin).';
                } else {
                    $log[] = '✔ public/storage havolasi yaratildi';
                }
            } elseif (is_dir($link) && !is_link($link)) {
                // Arxivdan bo'sh papka kelgan bo'lishi mumkin
                if (count(scandir($link) ?: []) <= 2) {
                    @rmdir($link);
                    if (!@symlink($ROOT . '/storage/app/public', $link)) {
                        copyDir($ROOT . '/storage/app/public', $link);
                    }
                }
            }

            // 5) Frontend runtime config (qayta build kerak emas)
            $refBase = $in['mini_app'] !== ''
                ? "https://t.me/{$botUsername}/{$in['mini_app']}?startapp="
                : "https://t.me/{$botUsername}?start=";
            $cfg = [
                'API_URL' => $in['app_url'],
                'APP_URL' => $in['app_url'],
                'BOT_URL' => "https://t.me/{$botUsername}",
                'REFERRAL_BASE' => $refBase,
            ];
            file_put_contents($PUBLIC . '/config.js', 'window.__CF_CONFIG__ = ' . json_encode($cfg, JSON_UNESCAPED_SLASHES) . ";\n");
            file_put_contents($PUBLIC . '/tonconnect-manifest.json', json_encode([
                'url' => $in['app_url'], 'name' => 'Cool Frog', 'iconUrl' => $in['app_url'] . '/images/logo.png',
            ], JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));
            $log[] = '✔ public/config.js yozildi';

            // 6) Telegram webhook (PHP bot)
            if (str_starts_with($in['app_url'], 'https://')) {
                $hook = curlJson("https://api.telegram.org/bot{$in['bot_token']}/setWebhook", [
                    'url' => $in['app_url'] . '/api/telegram/webhook/' . $secret,
                    'secret_token' => $secret,
                    'allowed_updates' => ['message'],
                    'drop_pending_updates' => true,
                ]);
                $log[] = ($hook['ok'] ?? false ? '✔ ' : '✘ ') . 'Webhook: ' . ($hook['description'] ?? 'xato');
                if (!($hook['ok'] ?? false)) {
                    $errors[] = 'Webhook o\'rnatilmadi: ' . ($hook['description'] ?? '') . ' — saytingiz HTTPS orqali ochilishini tekshiring.';
                }
                $menu = curlJson("https://api.telegram.org/bot{$in['bot_token']}/setChatMenuButton", [
                    'menu_button' => ['type' => 'web_app', 'text' => 'Play', 'web_app' => ['url' => $in['app_url'] . '/']],
                ]);
                $log[] = ($menu['ok'] ?? false ? '✔ ' : '⚠ ') . 'Menyu tugmasi: ' . ($menu['description'] ?? 'OK');
                curlJson("https://api.telegram.org/bot{$in['bot_token']}/setMyCommands", [
                    'commands' => [['command' => 'start', 'description' => 'Play Cool Frog']],
                ]);
            } else {
                $errors[] = 'Telegram faqat HTTPS manzillarni qabul qiladi — webhook o\'rnatilmadi. Saytga SSL ulang va installni qayta ishga tushiring.';
            }

            // 7) Keshlar (xato bo'lsa e'tiborsiz)
            foreach (['config:cache', 'route:cache', 'view:cache'] as $c) {
                try {
                    $run($c);
                } catch (Throwable $ex) {
                    $log[] = "⚠ $c o'tkazib yuborildi: " . $ex->getMessage();
                }
            }

            file_put_contents($LOCK, date('c') . "\n");
            $done = empty($errors);
            $installed = true;
        } catch (Throwable $ex) {
            $errors[] = 'O\'rnatish to\'xtadi: ' . $ex->getMessage() . ' (' . basename($ex->getFile()) . ':' . $ex->getLine() . ')';
        }
    }
}

/* ---------- O'zini o'chirish ---------- */
$selfDeleted = null;
if ($action === 'selfdelete' && $installed) {
    @unlink($PUBLIC . '/install.php');
    $selfDeleted = @unlink(__DIR__ . '/install.php') || !is_file(__DIR__ . '/install.php');
}

$reqs = requirements($ROOT, $PUBLIC);
$blocking = array_filter($reqs, fn ($r) => $r[2] && !$r[1]);
$needVendor = !is_file($ROOT . '/vendor/autoload.php');
?>
<!doctype html>
<html lang="uz">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>CoolFrog o'rnatuvchi</title>
<style>
body{font-family:system-ui,Arial,sans-serif;background:#0f1a12;color:#e8f5e9;margin:0;padding:16px}
.wrap{max-width:720px;margin:0 auto}
h1{color:#8bc34a;margin:8px 0 16px}
.card{background:#16261b;border:1px solid #2a4a33;border-radius:12px;padding:16px;margin-bottom:16px}
label{display:block;margin:10px 0 4px;font-size:14px;color:#b6d7b9}
input[type=text],input[type=password],input[type=email],input[type=number]{width:100%;box-sizing:border-box;padding:10px;border-radius:8px;border:1px solid #2f5a3a;background:#0f1a12;color:#fff;font-size:15px}
button{background:#8bc34a;color:#10230f;border:0;border-radius:8px;padding:12px 18px;font-size:16px;font-weight:700;cursor:pointer;margin-top:14px}
button.sec{background:#2f5a3a;color:#fff}
.ok{color:#8bc34a}.bad{color:#ff6b6b}.warn{color:#ffca28}
pre{white-space:pre-wrap;background:#0b130d;padding:10px;border-radius:8px;font-size:12px;max-height:340px;overflow:auto}
.err{background:#3a1616;border:1px solid #7a2b2b;border-radius:10px;padding:10px;margin-bottom:10px}
small{color:#8aa78d}
.row{display:flex;gap:10px}.row>div{flex:1}
</style>
</head>
<body><div class="wrap">
<h1>🐸 CoolFrog o'rnatuvchi</h1>

<?php foreach ($errors as $er): ?><div class="err">⚠ <?= e($er) ?></div><?php endforeach; ?>
<?php if ($log): ?><div class="card"><b>Jarayon:</b><pre><?= e(implode("\n", $log)) ?></pre></div><?php endif; ?>

<?php if ($selfDeleted !== null): ?>
  <div class="card"><?= $selfDeleted ? '<span class="ok">✔ install.php o\'chirildi.</span>' : '<span class="bad">install.php ni o\'chirib bo\'lmadi — uni fayl menejeridan qo\'lda o\'chiring.</span>' ?></div>
<?php elseif ($installed): ?>
  <div class="card">
    <?php if ($done): ?><h2 class="ok">✔ O'rnatish tugadi!</h2><?php else: ?><h2 class="warn">O'rnatish yakunlandi (ogohlantirishlar bilan)</h2><?php endif; ?>
    <p>O'yin: <a style="color:#8bc34a" href="<?= e($in['app_url']) ?>/"><?= e($in['app_url']) ?>/</a><br>
       Admin panel: <a style="color:#8bc34a" href="<?= e($in['app_url']) ?>/admin"><?= e($in['app_url']) ?>/admin</a></p>
    <p>Botga <b>/start</b> yuboring — "Play Game" tugmasi chiqishi kerak. <small>Bot webhook orqali ishlaydi, pm2/Node kerak emas.</small></p>
    <p class="bad"><b>Xavfsizlik:</b> endi install.php ni o'chiring.</p>
    <form method="post"><input type="hidden" name="action" value="selfdelete"><button>install.php ni o'chirish</button></form>
  </div>
<?php else: ?>
  <div class="card">
    <b>1. Talablar</b>
    <ul style="list-style:none;padding-left:0;line-height:1.7">
      <?php foreach ($reqs as [$label, $ok, $must]): ?>
        <li class="<?= $ok ? 'ok' : ($must ? 'bad' : 'warn') ?>"><?= $ok ? '✔' : ($must ? '✘' : '⚠') ?> <?= e($label) ?></li>
      <?php endforeach; ?>
    </ul>
    <?php if ($needVendor): ?>
      <p class="warn">vendor/ topilmadi. Server ruxsat bersa, kutubxonalar avtomatik o'rnatiladi (bir necha daqiqa):</p>
      <form method="post"><input type="hidden" name="action" value="composer"><button class="sec">Kutubxonalarni o'rnatish (composer)</button></form>
    <?php endif; ?>
    <?php if (!is_file($PUBLIC . '/index.html')): ?>
      <p class="warn">public/index.html yo'q: o'yin frontendi hali yig'ilmagan (README.md "Frontend" bo'limi). Backend va bot baribir o'rnatiladi.</p>
    <?php endif; ?>
  </div>

  <form method="post" class="card" autocomplete="off">
    <input type="hidden" name="action" value="install">
    <b>2. Sayt manzili</b>
    <label>Domen (https bilan, oxirida "/" siz)</label>
    <input type="text" name="app_url" value="<?= e($in['app_url']) ?>" required>

    <b style="display:block;margin-top:18px">3. MySQL bazasi</b>
    <div class="row">
      <div><label>Host</label><input type="text" name="db_host" value="<?= e($in['db_host']) ?>" required></div>
      <div><label>Port</label><input type="text" name="db_port" value="<?= e($in['db_port']) ?>" required></div>
    </div>
    <label>Baza nomi</label><input type="text" name="db_name" value="<?= e($in['db_name']) ?>" required>
    <label>Foydalanuvchi</label><input type="text" name="db_user" value="<?= e($in['db_user']) ?>" required>
    <label>Parol</label><input type="password" name="db_pass" value="<?= e($in['db_pass']) ?>">
    <label><input type="checkbox" name="force" <?= $in['force'] ? 'checked' : '' ?>> Mavjud jadvallarni o'chirib qayta o'rnatish (ma'lumotlar yo'qoladi!)</label>

    <b style="display:block;margin-top:18px">4. Telegram bot</b>
    <label>Bot tokeni (@BotFather)</label>
    <input type="text" name="bot_token" value="<?= e($in['bot_token']) ?>" placeholder="123456789:AA..." required>
    <label>Mini App qisqa nomi (ixtiyoriy)</label>
    <input type="text" name="mini_app" value="<?= e($in['mini_app']) ?>" placeholder="masalan: play">
    <small>BotFather → /newapp bilan yaratgan bo'lsangiz kiriting. Bo'sh qoldirsangiz, taklif havolalari <code>t.me/bot?start=ref…</code> ko'rinishida bo'ladi va baribir ishlaydi.</small>

    <b style="display:block;margin-top:18px">5. Admin</b>
    <label>Ism</label><input type="text" name="admin_name" value="<?= e($in['admin_name']) ?>">
    <label>Email</label><input type="email" name="admin_email" value="<?= e($in['admin_email']) ?>" required>
    <label>Parol (kamida 8 belgi)</label><input type="password" name="admin_pass" required>
    <label><input type="checkbox" name="sample" <?= $in['sample'] ? 'checked' : '' ?>> Namuna vazifalar va popup qo'shilsin (keyin adminda o'zgartirasiz)</label>

    <button <?= $blocking ? 'disabled title="Avval qizil bandlarni tuzating"' : '' ?>>O'rnatish</button>
  </form>
<?php endif; ?>
</div></body></html>
