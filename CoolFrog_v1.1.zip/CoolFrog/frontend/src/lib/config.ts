/**
 * Runtime sozlamalar: install.php yozadigan public/config.js (window.__CF_CONFIG__) dan o'qiladi,
 * shuning uchun domen o'zgarsa qayta build qilish shart emas.
 * Lokal ishlab chiqishda .env dagi VITE_* qiymatlari ishlatiladi.
 */
type RuntimeConfig = {
  API_URL?: string;
  APP_URL?: string;
  BOT_URL?: string;
  REFERRAL_BASE?: string;
};

declare global {
  interface Window {
    __CF_CONFIG__?: RuntimeConfig;
  }
}

const runtime: RuntimeConfig = window.__CF_CONFIG__ ?? {};

const botUrl = runtime.BOT_URL ?? import.meta.env.VITE_BOT_URL ?? "";

export const config = {
  API_URL: runtime.API_URL ?? import.meta.env.VITE_API_URL ?? "",
  APP_URL: runtime.APP_URL ?? import.meta.env.VITE_APP_URL ?? "",
  BOT_URL: botUrl,
  REFERRAL_BASE: runtime.REFERRAL_BASE ?? `${botUrl}/?startapp=`,
};
