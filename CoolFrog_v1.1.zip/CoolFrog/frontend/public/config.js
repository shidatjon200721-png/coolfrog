// install.php shu faylni qayta yozadi. Lokal ishlab chiqishda bo'sh qoladi (.env dagi VITE_* ishlatiladi).
window.__CF_CONFIG__ = window.__CF_CONFIG__ || {};
