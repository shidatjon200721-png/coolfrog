<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Botga "/start ref123" bilan kelgan, lekin hali o'yinga kirmagan foydalanuvchilar.
     */
    public function up(): void
    {
        Schema::create('bot_referrals', function (Blueprint $table) {
            $table->unsignedBigInteger('telegram_id')->primary();
            $table->unsignedBigInteger('referred_by');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('bot_referrals');
    }
};
