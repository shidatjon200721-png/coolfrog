# CoolFrog v1.1 — Telegram Tap2Earn (Laravel API + React Mini App + PHP bot)

Bitta domen, hammasi bir joyda:

| Manzil | Nima |
|---|---|
| `https://domen/` | O'yin (React Mini App) |
| `https://domen/api/...` | O'yin API (Laravel) |
| `https://domen/admin` | Admin panel (vazifalar, foydalanuvchilar) |
| `https://domen/api/telegram/webhook/...` | **Telegram bot** (PHP webhook — pm2/Node **kerak emas**) |

## O'rnatish (3 qadam)

1. **Tayyor ZIP ni** hostingga yuklab, `public_html` (domen ildizi) ichiga oching.
   - Agar ZIP da `vendor/` va `public/index.html` bo'lmasa, quyidagi **"Tayyor ZIP olish"** bo'limiga qarang.
2. Brauzerda `https://domen/install.php` ni oching → bazaga ulanish, bot tokeni (@BotFather), admin email/parol kiriting → **O'rnatish**.
   Installer: `.env` yaratadi, APP_KEY generatsiya qiladi, migratsiya + seed qiladi, admin yaratadi, `public/config.js` yozadi, **bot webhookini o'rnatadi**.
3. `install.php` ni o'chiring (installer tugmasi bor). Botga `/start` yuboring.

Talablar: PHP 8.2+, MySQL, HTTPS (Telegram talabi), `pdo_mysql, mbstring, openssl, tokenizer, xml, ctype, json, fileinfo, curl`.

### Tayyor ZIP olish (vendor + frontend)
Kod manbasida `vendor/` (composer) va `public/index.html` (React build) yo'q — ularni bir marta yig'ish kerak. Eng oson yo'llar:

- **GitHub Actions (kompyuter shart emas):** loyihani GitHub repoga yuklang → *Actions → Build release → Run workflow* → natijada `CoolFrog-ready.zip` artefaktini yuklab oling.
- **Kompyuterda:** PHP 8.2 + composer + Node 18+ bo'lsa: `bash build-release.sh` → `CoolFrog-ready.zip`.
- **Faqat vendor/:** hosting `exec/proc_open` ruxsat bersa, `install.php` dagi "Kutubxonalarni o'rnatish" tugmasi composer ni o'zi yuklab ishlatadi. (Frontend baribir yuqoridagidek yig'iladi.)

Frontend uchun qayta build **domen o'zgarganda kerak emas** — manzillar `public/config.js` dan o'qiladi.

## Nginx (docroot = `public/`)
```
root /var/www/coolfrog/public;
index index.html index.php;
location ~ ^/(api|admin|up)(/|$) { try_files $uri /index.php?$query_string; }
location / { try_files $uri $uri/ /index.html; }
location ~ \.php$ { include fastcgi_params; fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name; fastcgi_pass unix:/run/php/php8.2-fpm.sock; }
location ~ /\.(?!well-known) { deny all; }
```

## BotFather
- Mini App ixtiyoriy: `/newapp` bilan yarating va installerda qisqa nomini kiriting → taklif havolasi `t.me/bot/nom?startapp=ref…`. Kiritmasangiz havola `t.me/bot?start=ref…` bo'ladi va bot `/start` payload'ini o'zi eslab qoladi (referal baribir ishlaydi).
- Webhook qayta o'rnatish kerak bo'lsa (SSH bor bo'lsa): `php artisan telegram:webhook`.

## Nimalar tuzatildi (asl kodga nisbatan)
**Xavfsizlik**
- `/auth/telegram-user` **istalgan telegram_id** bilan token berar edi (boshqa odam nomidan kirish mumkin). Endi Telegram `initData` HMAC imzosi bot tokeni bilan tekshiriladi (+ 24 soatlik muddat).
- Admin panelda `register` ochiq edi — **har kim admin bo'la olardi**. Olib tashlandi; admin faqat installer orqali.
- Admin kirishi umuman ishlamas edi (`auth.php` provayderi `TelegramUser` ga ulangan) → `User` ga tuzatildi.
- `buy-booster` **tekin** edi (balans tekshirilmas/yechilmas edi), `buy-booster-pack` ham tekin x7 berar edi (frontend ishlatmaydi) — endi booster narxi balansdan yechiladi, pack route'i o'chirildi.
- Missiyalar: istalgan darajani, istalgan marta sotib olish mumkin edi; `required_user_level` / `required_friends_invitation` faqat frontendda tekshirilar edi — endi serverda ham.
- Vazifa mukofoti: 60 daqiqa kutish faqat frontendda edi — endi serverda ham; parallel so'rovlar bilan ikki marta olish yopildi (qator qulflash + unique indekslar).
- Oflayn daromadni parallel `sync` so'rovlari bilan ko'paytirish yopildi.
- Reyting va do'stlar ro'yxati `ton_wallet`, `referred_by` kabi ortiqcha maydonlarni oshkor qilar edi.
- Frontenddagi uchinchi tomon **Google Tag Manager** (sotuvchining `GTM-PKZG3L8R` konteyneri) olib tashlandi.
- `.env` (eski APP_KEY), `laravel.log`, kompilyatsiya qilingan view'lar arxivdan olib tashlandi; yangi APP_KEY installerda.

**Xatolar**
- Tap: server har bosishga 1 energiya yechar, frontend `earn_per_tap` — mos emas edi; va server energiyani vaqt bo'yicha tiklamasdan hisoblagani uchun uzoq o'ynagan o'yinchi tangalarni yo'qotardi. Tuzatildi.
- `sync` javobida `booster_pack_x2` kaliti 3 marta qayta yozilgan edi.
- `routes/api.php` dagi `/test` yo'li import qilinmagan `Request/Http` bilan buzuq edi — olib tashlandi.
- `balance` ustuni `int` (2.1 mlrd da to'lib ketadi) → `bigint`; `levels.from_balance` ham.
- Admin "Create Task" formasi majburiy `type/action_name/link` maydonlarisiz edi (har safar SQL xato) — to'ldirildi.
- Admin sahifalari `@vite` (build qilinmagan manifest) tufayli ochilmas edi — CDN ga o'tkazildi.
- `env()` ni konfigdan tashqarida ishlatish (`config:cache` da null qaytaradi) — `url()` ga almashtirildi.
- Seederlar qayta ishga tushganda dublikat yaratar edi; ReferralTask/Popup seederlari umuman chaqirilmas edi.
- Level-up faqat `balance` to'g'ridan-to'g'ri saqlanganda ishlar edi; endi vazifa/kunlik mukofot/missiya/oflayn daromaddan keyin ham tekshiriladi, do'stga bonus barcha o'tilgan darajalar uchun beriladi, Premium foydalanuvchi uchun `premium` jadvali ishlatiladi.
- Frontend: token boshqa Telegram akkauntiga tegishli bo'lsa qayta kiradi; API xatosida cheksiz splash o'rniga "Retry".

**Bot**: `bot/` (Node + Telegraf + pm2) o'rniga `TelegramWebhookController` (PHP). `/start` o'sha tugma bilan javob beradi, `/start ref123` payload'ini ham qo'llaydi, menyu tugmasi (Play) o'rnatiladi.

## Eslatma
- Vazifalar/missiyalar/darajalar: admin panel yoki `database/seeders/*`.
- TON to'lovlari asl kodda ham yo'q edi (TonConnect faqat ulangan, hech narsa sotilmaydi).
- Subpapkada (`domen.com/game/`) ishlamaydi — domen yoki subdomen ildizi kerak.
