#!/usr/bin/env bash
# Kompyuteringizda tayyor ZIP yig'ish:  bash build-release.sh
# Kerak: PHP 8.2+, composer, Node 18+ (npm)
set -euo pipefail
cd "$(dirname "$0")"

if [ "${1:-}" != "--skip-install" ]; then
  composer install --no-dev --no-interaction --prefer-dist --optimize-autoloader --no-scripts
  (cd frontend && npm ci && npm run build)
fi

# Frontend dist -> public/  (config.js ni dist ichidagisi bilan almashtiramiz — u ham bo'sh)
cp -R frontend/dist/. public/

rm -f CoolFrog-ready.zip
zip -rq CoolFrog-ready.zip . \
  -x "frontend/node_modules/*" "frontend/dist/*" ".git/*" ".github/*" ".env" \
     "storage/logs/*.log" "storage/framework/views/*.php" "storage/installed.lock" \
     "bootstrap/cache/*.php" "*.zip"
echo "Tayyor: CoolFrog-ready.zip  (hostingga yuklab, /install.php ni oching)"
