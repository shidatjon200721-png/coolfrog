<?php
// Ildizdagi install.php ni ishga tushiradi (docroot = public/ bo'lgan hostinglar uchun).
require dirname(__DIR__) . '/install.php';
